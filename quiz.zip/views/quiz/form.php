<div class="page-head"><div><a class="back" href="<?=url('course/'.$courseId)?>">← Курс</a><span class="eyebrow">КОНСТРУКТОР ТЕСТУ</span><h1><?=$quiz?'Редагувати тест':'Новий тест'?></h1><p class="muted">Починайте з <b>2 відповідей</b>. За потреби додавайте ще — правильну відповідь можна змінити в будь-який момент.</p></div></div>
<form method="post" enctype="multipart/form-data" class="stack" id="quiz-form"><input type="hidden" name="csrf" value="<?=csrf()?>">
<div class="card form"><label>Назва<input name="title" value="<?=e($quiz['title']??'')?>" required></label><label>Опис<textarea name="description"><?=e($quiz['description']??'')?></textarea></label></div>
<div id="questions" class="stack">
<?php foreach($questions as $i=>$q): ?><div class="card question-editor" data-question>
<div class="section-title"><h3>Питання <?=$i+1?></h3><button type="button" class="btn danger" data-remove-question>🗑 Прибрати</button></div>
<input type="hidden" name="question_id[<?=$i?>]" value="<?=$q['id']?>">
<label>Питання<textarea name="question_text[<?=$i?>]" required><?=e($q['question_text'])?></textarea></label>
<?php if($q['image_path']): ?><img class="editor-image" src="<?=e(base_url().'/'.$q['image_path'])?>" alt="">
<?php endif; ?><label>Зображення<input type="file" name="question_image_<?=$i?>" accept="image/*"></label>
<div class="answer-editor" data-answers>
<div class="answer-editor-head"><b>Варіанти відповідей</b><button type="button" class="btn ghost small" data-add-answer>＋ Додати відповідь</button></div>
<?php foreach($q['answers'] as $ai=>$a): ?><div class="answer-line" data-answer><input name="answers[<?=$i?>][<?=$ai?>]" value="<?=e($a['answer_text'])?>" placeholder="Варіант <?=($ai+1)?>"><label class="radio"><input type="radio" name="correct[<?=$i?>]" value="<?=$ai?>" <?=$a['is_correct']?'checked':''?>> правильний</label><button type="button" class="icon-btn" data-remove-answer title="Видалити відповідь">×</button></div><?php endforeach; ?>
</div><div class="answer-hint">Мінімум 2 заповнені відповіді. Для учня порядок відповідей можна перемішувати.</div>
</div><?php endforeach; ?></div>
<div class="actions"><button type="button" class="btn ghost" id="add-question">＋ Додати питання</button><button class="btn primary">💾 Зберегти тест</button></div></form>

<script>
(() => {
  let qi = <?=max(count($questions),0)?>;
  const questions = document.getElementById('questions');

  function answerHtml(qi, ai, text='', correct=false){
    return `<div class="answer-line" data-answer><input name="answers[${qi}][${ai}]" value="${escapeHtml(text)}" placeholder="Варіант ${ai+1}"><label class="radio"><input type="radio" name="correct[${qi}]" value="${ai}" ${correct?'checked':''}> правильний</label><button type="button" class="icon-btn" data-remove-answer title="Видалити відповідь">×</button></div>`;
  }
  function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));}
  function renumber(){
    [...questions.querySelectorAll('[data-question]')].forEach((q,n)=>q.querySelector('h3').textContent=`Питання ${n+1}`);
  }
  function addQuestion(){
    const i=qi++;
    const d=document.createElement('div'); d.className='card question-editor question-new'; d.dataset.question='';
    d.innerHTML=`<div class="section-title"><h3>Питання</h3><button type="button" class="btn danger" data-remove-question>🗑 Прибрати</button></div>
      <input type="hidden" name="question_id[${i}]" value="0"><label>Питання<textarea name="question_text[${i}]" required></textarea></label>
      <label>Зображення<input type="file" name="question_image_${i}" accept="image/*"></label>
      <div class="answer-editor" data-answers><div class="answer-editor-head"><b>Варіанти відповідей</b><button type="button" class="btn ghost small" data-add-answer>＋ Додати відповідь</button></div>
      ${answerHtml(i,0,'',true)}${answerHtml(i,1,'',false)}</div><div class="answer-hint">Мінімум 2 заповнені відповіді.</div>`;
    questions.appendChild(d); renumber(); d.querySelector('textarea').focus();
  }
  function addAnswer(box){
    const q=box.closest('[data-question]');
    const hidden=q.querySelector('input[name^="question_id"]');
    const qiMatch=hidden.name.match(/\[(\d+)\]/); const qid=qiMatch?qiMatch[1]:0;
    const used=[...box.querySelectorAll('[data-answer] input[type=text], [data-answer] input:not([type=radio])')].map(x=>x.name.match(/\[(\d+)\]$/)?.[1]).filter(Boolean).map(Number);
    const ai=used.length?Math.max(...used)+1:0;
    box.insertAdjacentHTML('beforeend',answerHtml(qid,ai));
    box.lastElementChild?.querySelector('input:not([type=radio])')?.focus();
  }
  function removeAnswer(row){
    const box=row.closest('[data-answers]');
    const rows=box.querySelectorAll('[data-answer]');
    if(rows.length<=2){row.animate([{transform:'translateX(0)'},{transform:'translateX(-5px)'},{transform:'translateX(5px)'},{transform:'translateX(0)'}],{duration:220});return;}
    const radio=row.querySelector('input[type=radio]'); const was=radio?.checked;
    row.classList.add('answer-removing');
    setTimeout(()=>{row.remove(); if(was){const first=box.querySelector('[data-answer] input[type=radio]'); if(first) first.checked=true;}},180);
  }
  questions.addEventListener('click',e=>{
    if(e.target.closest('[data-add-answer]')) addAnswer(e.target.closest('[data-answers]'));
    if(e.target.closest('[data-remove-answer]')) removeAnswer(e.target.closest('[data-remove-answer]').closest('[data-answer]'));
    if(e.target.closest('[data-remove-question]')){
      const q=e.target.closest('[data-question]'); q.classList.add('question-removing'); setTimeout(()=>{q.remove();renumber();},180);
    }
  });
  document.getElementById('add-question').addEventListener('click',addQuestion);
  document.getElementById('quiz-form').addEventListener('submit',e=>{
    let bad=false;
    questions.querySelectorAll('[data-question]').forEach(q=>{
      const filled=[...q.querySelectorAll('[data-answer] input:not([type=radio])')].filter(x=>x.value.trim()).length;
      if(filled<2){bad=true;q.classList.add('validation-shake');setTimeout(()=>q.classList.remove('validation-shake'),350);}
    });
    if(bad){e.preventDefault();alert('У кожному питанні має бути щонайменше 2 заповнені відповіді.');}
  });
  if(!questions.querySelector('[data-question]')) addQuestion();
})();
</script>
