<div class="page-head"><div><a class="back" href="<?=url('course/'.$courseId)?>">← Курс</a><span class="eyebrow">КАРТКИ</span><h1>Навчальні картки</h1><p class="muted">Додавайте кілька карток за один раз. Зображення можна додати до обох сторін.</p></div></div>
<form method="post" enctype="multipart/form-data" class="stack"><input type="hidden" name="csrf" value="<?=csrf()?>"><div id="cards" class="stack"></div><div class="actions"><button type="button" class="btn ghost" onclick="addCard()">＋ Додати картку</button><button class="btn primary">💾 Зберегти</button></div></form>
<script>
let ci=0;
function addCard(){
 const i=ci++,d=document.createElement('div');d.className='card grid2 card-builder';
 d.innerHTML=`<div class="stack"><label>Лицьова сторона<textarea name="front[${i}]" required></textarea></label><label>Зображення лицьової<input type="file" name="front_image_${i}" accept="image/*"></label></div><div class="stack"><label>Зворотна сторона<textarea name="back[${i}]" required></textarea></label><label>Зображення зворотної<input type="file" name="back_image_${i}" accept="image/*"></label></div><button type="button" class="icon-btn card-remove" onclick="this.closest('.card').remove()">×</button>`;
 document.getElementById('cards').appendChild(d);d.querySelector('textarea').focus();
}
addCard();
</script>