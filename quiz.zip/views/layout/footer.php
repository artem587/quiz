</main>
<footer>QuizSpace · навчальна платформа</footer>
<div class="confirm-modal" id="confirm-modal" aria-hidden="true"><div class="confirm-backdrop" data-confirm-cancel></div><div class="confirm-box" role="dialog" aria-modal="true" aria-labelledby="confirm-title"><div class="confirm-icon">!</div><h3 id="confirm-title">Підтвердити видалення?</h3><p id="confirm-text">Цю дію не можна скасувати.</p><div class="actions"><button type="button" class="btn ghost" data-confirm-cancel>Скасувати</button><button type="button" class="btn danger" id="confirm-ok">Видалити</button></div></div></div>
<script>
(()=>{const modal=document.getElementById('confirm-modal'),ok=document.getElementById('confirm-ok'),text=document.getElementById('confirm-text');let form=null;
function close(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');form=null}document.addEventListener('click',e=>{const btn=e.target.closest('[data-confirm]');if(btn){e.preventDefault();form=btn.closest('form');text.textContent=btn.dataset.confirm||'Цю дію не можна скасувати.';modal.classList.add('open');modal.setAttribute('aria-hidden','false');return}if(e.target.closest('[data-confirm-cancel]'))close()});ok.onclick=()=>{if(form){form.removeAttribute('data-confirm');form.submit()}close()};document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});})();
</script>
</body></html>
