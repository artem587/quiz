<!doctype html>
<html lang="uk">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e(env('APP_NAME','QuizSpace'))?></title>
<link rel="stylesheet" href="<?=e(base_url())?>/public/css/style.css?v=33">
</head>
<body>
<header class="top">
  <a class="brand" href="<?=url('home')?>"><span class="logo">Q</span><span>QuizSpace</span></a>
  <nav class="main-nav">
    <?php if($me): ?>
      <a href="<?=url('home')?>">Головна</a>
      <?php if($me['role']==='teacher'): ?><a href="<?=url('teacher/courses')?>">Мої курси</a><?php endif; ?>
      <?php if($me['role']==='admin'): ?><a href="<?=url('admin/teachers')?>">Вчителі</a><?php endif; ?>
    <?php endif; ?>
  </nav>
  <?php if($me): ?>
    <div class="user-menu"><span><?=e($me['name'])?></span><span class="pill"><?=e($me['role'])?></span><a class="btn ghost small" href="<?=url('logout')?>">Вийти</a></div>
  <?php endif; ?>
</header>
<main class="container">
<?php if($m=flash()): ?><div class="flash"><?=e($m)?></div><?php endif; ?>
