<?php
declare(strict_types=1);

function env(string $key, string $default=''): string {
    static $vars = null;
    if ($vars === null) {
        $vars = [];
        $path = dirname(__DIR__) . '/.env';
        if (is_file($path)) {
            foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
                $line = trim($line);
                if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
                [$k,$v] = explode('=', $line, 2);
                $vars[trim($k)] = trim($v, " \t\n\r\0\x0B\"'");
            }
        }
    }
    return $vars[$key] ?? $default;
}

if (env('APP_DEBUG','false') === 'true') {
    ini_set('display_errors','1');
    ini_set('display_startup_errors','1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors','0');
    ini_set('display_startup_errors','0');
    error_reporting(E_ALL);
}

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host='.env('DB_HOST','127.0.0.1').';port='.env('DB_PORT','3306').';dbname='.env('DB_NAME','quiz').';charset=utf8mb4';
    $pdo = new PDO($dsn, env('DB_USER','root'), env('DB_PASS',''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    // InfinityFree/legacy imports can have mixed collations. Force UTF-8
    // for every connection so newly saved Cyrillic/Ukrainian text is preserved.
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    return $pdo;
}

function base_url(): string {
    return rtrim(env('BASE_URL', env('APP_URL','http://localhost/quiz')), '/');
}
function url(string $path=''): string {
    return base_url() . ($path ? '/index.php?url='.rawurlencode(trim($path,'/')) : '/');
}
function redirect(string $path): never { header('Location: '.url($path)); exit; }
function e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8'); }

function csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419); exit('CSRF token mismatch');
    }
}
function flash(?string $msg=null): ?string {
    if ($msg !== null) { $_SESSION['flash']=$msg; return null; }
    $x=$_SESSION['flash']??null; unset($_SESSION['flash']); return $x;
}
function me(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    static $u = false;
    if ($u === false) {
        $s=db()->prepare('SELECT * FROM users WHERE id=?');
        $s->execute([(int)$_SESSION['user_id']]);
        $u=$s->fetch() ?: null;
    }
    return $u;
}
function require_login(): array { $u=me(); if(!$u) redirect('login'); return $u; }
function require_role(string ...$roles): array {
    $u=require_login();
    if (!in_array($u['role'],$roles,true)) { http_response_code(403); exit('Доступ запрещён'); }
    return $u;
}
function can_manage_course(int $courseId, array $u): bool {
    if ($u['role']==='admin') return true;
    $s=db()->prepare('SELECT 1 FROM courses WHERE id=? AND teacher_id=?');
    $s->execute([$courseId,$u['id']]);
    return (bool)$s->fetchColumn();
}
function can_access_course(int $courseId, array $u): bool {
    if ($u['role']==='admin') return true;
    if ($u['role']==='teacher') return can_manage_course($courseId,$u);
    $s=db()->prepare("SELECT 1 FROM course_members WHERE course_id=? AND student_id=? AND status='active'");
    $s->execute([$courseId,$u['id']]);
    return (bool)$s->fetchColumn();
}
function view(string $file, array $data=[]): void {
    $data['me'] = $data['me'] ?? me();
    extract($data, EXTR_SKIP);
    require dirname(__DIR__).'/views/layout/header.php';
    require dirname(__DIR__).'/views/'.$file.'.php';
    require dirname(__DIR__).'/views/layout/footer.php';
}
function upload_image(string $field): ?string {
    if (empty($_FILES[$field]['name']) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
    if ($_FILES[$field]['size'] > 5*1024*1024) throw new RuntimeException('Изображение слишком большое (максимум 5 МБ).');
    if (!function_exists('finfo_open')) throw new RuntimeException('На сервере не включён Fileinfo.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES[$field]['tmp_name']);
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    if (!isset($allowed[$mime])) throw new RuntimeException('Разрешены только JPG, PNG, WEBP и GIF.');
    $dir=dirname(__DIR__).'/public/uploads';
    if (!is_dir($dir) && !@mkdir($dir,0775,true) && !is_dir($dir)) throw new RuntimeException('Не удалось создать public/uploads.');
    if (!is_writable($dir)) throw new RuntimeException('Папка public/uploads недоступна для записи.');
    $name=bin2hex(random_bytes(12)).'.'.$allowed[$mime];
    if (!move_uploaded_file($_FILES[$field]['tmp_name'],$dir.'/'.$name)) throw new RuntimeException('Не удалось сохранить изображение.');
    return 'public/uploads/'.$name;
}
function delete_file(?string $path): void {
    if ($path && str_starts_with($path,'public/uploads/')) {
        $full=dirname(__DIR__).'/'.$path;
        if (is_file($full)) @unlink($full);
    }
}
function send_reset_code(string $email, string $code): bool {
    $subject='QuizSpace — код восстановления пароля';
    $message="Ваш код восстановления: {$code}\nКод действует 10 минут.";
    $from=env('MAIL_FROM','no-reply@quizspace.local');
    $headers="MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nFrom: {$from}\r\n";
    return @mail($email,$subject,$message,$headers);
}
